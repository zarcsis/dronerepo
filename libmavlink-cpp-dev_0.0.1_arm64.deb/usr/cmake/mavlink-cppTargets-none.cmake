#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mavlinkcpp::mavlink-cpp" for configuration "None"
set_property(TARGET mavlinkcpp::mavlink-cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(mavlinkcpp::mavlink-cpp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libmavlink-cpp.a"
  )

list(APPEND _cmake_import_check_targets mavlinkcpp::mavlink-cpp )
list(APPEND _cmake_import_check_files_for_mavlinkcpp::mavlink-cpp "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libmavlink-cpp.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
