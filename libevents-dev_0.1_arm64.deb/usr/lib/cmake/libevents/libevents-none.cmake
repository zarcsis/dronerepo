#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libevents_parser" for configuration "None"
set_property(TARGET libevents_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(libevents_parser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblibevents_parser.a"
  )

list(APPEND _cmake_import_check_targets libevents_parser )
list(APPEND _cmake_import_check_files_for_libevents_parser "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblibevents_parser.a" )

# Import target "libevents_health_and_arming_checks" for configuration "None"
set_property(TARGET libevents_health_and_arming_checks APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(libevents_health_and_arming_checks PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblibevents_health_and_arming_checks.a"
  )

list(APPEND _cmake_import_check_targets libevents_health_and_arming_checks )
list(APPEND _cmake_import_check_files_for_libevents_health_and_arming_checks "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblibevents_health_and_arming_checks.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
